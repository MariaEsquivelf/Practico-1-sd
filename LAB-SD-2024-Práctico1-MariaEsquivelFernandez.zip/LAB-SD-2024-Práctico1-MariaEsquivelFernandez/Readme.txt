Informe de Practico #1

Implemente los todos las funcionalidades solicitadas en el practico.
Como puntos adicionales agregue manejo y muestra de errores. El programa permite agregar una descripción para cada ingreso y gasto. Implemente gráficos simples para visualizar los ingresos y gastos en la pantalla de inicio. Agregue una opción para eliminar ingresos o gastos de la lista.

MODO DE EJECUCION

Luego de descargar el archivo, ejecutar en el navegador el archivo index.html

MODO DE USO

Pantalla principal o de balance: aqui podemos ver graficos y datos simples de los ingresos, egresos y balance
Navbar: con el nav podemos ir cambiando entre cada pantalla
Pantallas de ingresos y egresos: en estas pantallas podemos ver las listas de cada uno y agregar nuevos registros